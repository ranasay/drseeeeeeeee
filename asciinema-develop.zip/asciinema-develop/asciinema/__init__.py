import sys

__author__ = 'Marcin Kulik'
__version__ = '2.0.0'

if sys.version_info[0] < 3:
    raise ImportError('Python < 3 is unsupported.')
